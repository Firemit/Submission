import os
import pickle
def reverse_fun():
      with open("users.json","rb") as f:
      data = f.read()
      conn,addr = self.receiver_socket.accept()
      recvd_digest, data = data.split(' ')
      new_digest = hmac.new('shared-key', data, hashlib.sha1).hexdigest()
      if recvd_digest != new_digest:
      print 'Integrity check failed'
      else:
      d = pickle.loads(data)
      return d

if __name__ == '__main__':
      print(reverse_fun())